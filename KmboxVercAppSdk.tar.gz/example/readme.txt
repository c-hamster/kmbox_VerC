视频类：
	00_getvi.cpp  ------------------测量输入视频采集延迟
	01_PrintScreen.cpp------------输入视频保存为BMP图片。可用于调试取色取样
	02_savemp4.cpp---------------输入视频保存为MP4。可用于动态过程采样。
	03_findpic.cpp-----------------找图demo
	04_facedetect.cpp-------------人脸检测demo
	readimg.cpp-------------------bmp图转换为灰度图
	templateMatching.cpp--------模板匹配算法


	
	
基本硬件类：
	demo.cpp-----------------------鼠标每隔1s下移100个单位
	lcd_demo------------------------lcd显示demo.(上电默认运行此程序。用于显示IP，CPU温度)


tools:
	config.ini------------------------kmbox的配置文件。用于修改VID\PID等参数。（注意：不要修改Ukey字段，改后kmbox的API不可调用）
	GetRegistCode------------------当你不小心删除config.ini文件后，可以用此程序获取本机的Ukey。发送给作者得到RSA秘钥。重新写入Ukey字段即可正常工作。

	