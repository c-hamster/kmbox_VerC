#if 1
#include "opencv2/objdetect.hpp"
#include "opencv2/highgui.hpp"
#include "opencv2/imgproc.hpp"
#include "opencv2/videoio.hpp"
#include <iostream>

using namespace std;
using namespace cv;


void detectAndDraw( Mat& img, CascadeClassifier& cascade, CascadeClassifier& nestedCascade,double scale, bool tryflip );

string cascadeName;
string nestedCascadeName;

int main( int argc, const char** argv )
{
    VideoCapture capture;
    Mat frame, image;
    string inputName;
    bool tryflip;
    CascadeClassifier cascade, nestedCascade;
    double scale;
    cv::CommandLineParser parser(argc, argv,
        "{help h||}"
        "{cascade|xml/haarcascade_frontalface_alt.xml|}"
        "{nested-cascade|haarcascade_eye_tree_eyeglasses.xml|}"
        "{scale|1|}{try-flip||}{@filename||}"
    );

    if (parser.has("help"))
    {
        return 0;
    }
    cascadeName = parser.get<string>("cascade");
    nestedCascadeName = parser.get<string>("nested-cascade");
    scale = parser.get<double>("scale");
    if (scale < 1)
        scale = 1;
    tryflip = parser.has("try-flip");
    inputName = parser.get<string>("@filename");
    if (!parser.check())
    {
        parser.printErrors();
        return 0;
    }
    if (!nestedCascade.load(samples::findFileOrKeep(nestedCascadeName)))
        cerr << "WARNING: Could not load classifier cascade for nested objects" << endl;
    if (!cascade.load(samples::findFile(cascadeName)))
    {
        cerr << "ERROR: Could not load classifier cascade" << endl;
        return -1;
    }
    if( inputName.empty() || (isdigit(inputName[0]) && inputName.size() == 1) )
    {
        int camera = inputName.empty() ? 0 : inputName[0] - '0';
        if(!capture.open(camera))
        {
            cout << "Capture from camera #" <<  camera << " didn't work" << endl;
            return 1;
        }
    }
    else if (!inputName.empty())
    {
        image = imread(samples::findFileOrKeep(inputName), IMREAD_COLOR);
        if (image.empty())
        {
            if (!capture.open(samples::findFileOrKeep(inputName)))
            {
                cout << "Could not read " << inputName << endl;
                return 1;
            }
        }
    }
    else
    {
        image = imread(samples::findFile("lena.jpg"), IMREAD_COLOR);
        if (image.empty())
        {
            cout << "Couldn't read lena.jpg" << endl;
            return 1;
        }
    }

    if( capture.isOpened() )
    {
        cout << "Video capturing has been started ..." << endl;
        for(;;)
        {
            capture >> frame;
            if( frame.empty() )
                break;

            Mat frame1 = frame.clone();
            detectAndDraw( frame1, cascade, nestedCascade, scale, tryflip );

        }
    }


    return 0;
}

void detectAndDraw( Mat& img, CascadeClassifier& cascade,
                    CascadeClassifier& nestedCascade,
                    double scale, bool tryflip )
{
    double t = 0;
    vector<Rect> faces, faces2;
    const static Scalar colors[] =
    {
        Scalar(255,0,0),
        Scalar(255,128,0),
        Scalar(255,255,0),
        Scalar(0,255,0),
        Scalar(0,128,255),
        Scalar(0,255,255),
        Scalar(0,0,255),
        Scalar(255,0,255)
    };
    Mat gray, smallImg;
    cvtColor( img, gray, COLOR_BGR2GRAY );
    double fx = 1 / scale;
    resize( gray, smallImg, Size(), fx, fx, INTER_LINEAR_EXACT );
    equalizeHist( smallImg, smallImg );

    t = (double)getTickCount();
    cascade.detectMultiScale( smallImg, faces,
        1.1, 2, 0
        //|CASCADE_FIND_BIGGEST_OBJECT
        //|CASCADE_DO_ROUGH_SEARCH
        |CASCADE_SCALE_IMAGE,
        Size(30, 30) );

    t = (double)getTickCount() - t;
    printf( "detection time = %g ms faces.size()=%d\n", t*1000/getTickFrequency(),faces.size());
    for ( size_t i = 0; i < faces.size(); i++ )
    {
        Rect r = faces[i];
        Mat smallImgROI;
        vector<Rect> nestedObjects;
        Point center;
        Scalar color = colors[i%8];
        int radius;
	
        double aspect_ratio = (double)r.width/r.height;
        if( 0.75 < aspect_ratio && aspect_ratio < 1.3 )
        {
            center.x = cvRound((r.x + r.width*0.5)*scale);
            center.y = cvRound((r.y + r.height*0.5)*scale);
            radius = cvRound((r.width + r.height)*0.25*scale);
            circle( img, center, radius, color, 3, 8, 0 );
        }
        else
            rectangle( img, Point(cvRound(r.x*scale), cvRound(r.y*scale)),
                       Point(cvRound((r.x + r.width-1)*scale), cvRound((r.y + r.height-1)*scale)),
                       color, 3, 8, 0);
        if( nestedCascade.empty() )
            continue;
        smallImgROI = smallImg( r );
        nestedCascade.detectMultiScale( smallImgROI, nestedObjects,
            1.1, 2, 0
            //|CASCADE_FIND_BIGGEST_OBJECT
            //|CASCADE_DO_ROUGH_SEARCH
            //|CASCADE_DO_CANNY_PRUNING
            |CASCADE_SCALE_IMAGE,
            Size(30, 30) );
        for ( size_t j = 0; j < nestedObjects.size(); j++ )
        {
            Rect nr = nestedObjects[j];
            center.x = cvRound((r.x + nr.x + nr.width*0.5)*scale);
            center.y = cvRound((r.y + nr.y + nr.height*0.5)*scale);
            radius = cvRound((nr.width + nr.height)*0.25*scale);
            circle( img, center, radius, color, 3, 8, 0 );
        }
    }

}
#else 
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/time.h>
#include <fcntl.h>
#include <time.h>
#include <stdio.h>
#include <unistd.h>
#include <linux/input.h>
#include <pthread.h> 
#include <string.h>
#include <signal.h>
#include <semaphore.h>
#include <sys/select.h>  
#include <string.h>
#include <memory.h>
#include<opencv2/opencv.hpp>
#include<opencv2/videoio/videoio_c.h>
#include<iostream>
#include <opencv2/core/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/opencv.hpp>
 
#include <vector>
#include <cstdio>
 
using namespace std;
using namespace cv;
 
VideoCapture cap;
VideoWriter outputVideo;
void help()
{
	printf("-----------kmbox_ai------------\n");
	printf("�沿ʶ���㷨\n");
    printf("�����ļ�:haarcascade_frontalface_alt.xml\n");
    printf("1920x1080@5Hz(�ڴ治���޷�����)\n");
	printf("1600x1200@5Hz(�ڴ治���޷�����)\n");
	printf("1360x768@8Hz(ok)\n");
	printf("1280X1240@8Hz(ok)\n");
	printf("1280X960@8Hz(ok)\n");
	printf("1280X720@10Hz(OK--�Ƽ�ʹ�� ����1920x1080)\n");
	printf("1024X768@10Hz(OK)\n");
	printf("800X600@20/10/5Hz(OK)\n");
	printf("720X576@25/20/10/5Hz(OK)\n");
	printf("720X480@30/20/10/5Hz(OK)\n");
	printf("640X480@30/20/10/5Hz(OK)\n");
	printf("-------------------------------\n");
}

 long GetUnixTime(){
    struct timeval stamp;
    gettimeofday(&stamp,NULL);
    return stamp.tv_sec*1000+stamp.tv_usec/1000;
}




void detectAndDraw( Mat& img, CascadeClassifier& cascade,
                    CascadeClassifier& nestedCascade,
                    double scale, bool tryflip )
{
    double t = 0;
    vector<Rect> faces, faces2;
    const static Scalar colors[] =
    {
        Scalar(255,0,0),
        Scalar(255,128,0),
        Scalar(255,255,0),
        Scalar(0,255,0),
        Scalar(0,128,255),
        Scalar(0,255,255),
        Scalar(0,0,255),
        Scalar(255,0,255)
    };
    Mat gray, smallImg;

    cvtColor( img, gray, COLOR_BGR2GRAY );
    double fx = 1 / scale;
    resize( gray, smallImg, Size(), fx, fx, INTER_LINEAR_EXACT );
    equalizeHist( smallImg, smallImg );

    t = (double)getTickCount();
    cascade.detectMultiScale( smallImg, faces,
        1.1, 2, 0
        //|CASCADE_FIND_BIGGEST_OBJECT
        //|CASCADE_DO_ROUGH_SEARCH
        |CASCADE_SCALE_IMAGE,
        Size(30, 30) );
    if( tryflip )
    {
        flip(smallImg, smallImg, 1);
        cascade.detectMultiScale( smallImg, faces2,
                                 1.1, 2, 0
                                 //|CASCADE_FIND_BIGGEST_OBJECT
                                 //|CASCADE_DO_ROUGH_SEARCH
                                 |CASCADE_SCALE_IMAGE,
                                 Size(30, 30) );
        for( vector<Rect>::const_iterator r = faces2.begin(); r != faces2.end(); ++r )
        {
            faces.push_back(Rect(smallImg.cols - r->x - r->width, r->y, r->width, r->height));
        }
    }
    t = (double)getTickCount() - t;
    printf( "detection time = %g ms\n", t*1000/getTickFrequency());
    for ( size_t i = 0; i < faces.size(); i++ )
    {
        Rect r = faces[i];
        Mat smallImgROI;
        vector<Rect> nestedObjects;
        Point center;
        Scalar color = colors[i%8];
        int radius;

        double aspect_ratio = (double)r.width/r.height;
        if( 0.75 < aspect_ratio && aspect_ratio < 1.3 )
        {
            center.x = cvRound((r.x + r.width*0.5)*scale);
            center.y = cvRound((r.y + r.height*0.5)*scale);
            radius = cvRound((r.width + r.height)*0.25*scale);
            circle( img, center, radius, color, 3, 8, 0 );
        }
        else
            rectangle( img, Point(cvRound(r.x*scale), cvRound(r.y*scale)),
                       Point(cvRound((r.x + r.width-1)*scale), cvRound((r.y + r.height-1)*scale)),
                       color, 3, 8, 0);
        if( nestedCascade.empty() )
            continue;
        smallImgROI = smallImg( r );
        nestedCascade.detectMultiScale( smallImgROI, nestedObjects,
            1.1, 2, 0
            //|CASCADE_FIND_BIGGEST_OBJECT
            //|CASCADE_DO_ROUGH_SEARCH
            //|CASCADE_DO_CANNY_PRUNING
            |CASCADE_SCALE_IMAGE,
            Size(30, 30) );
        for ( size_t j = 0; j < nestedObjects.size(); j++ )
        {
            Rect nr = nestedObjects[j];
            center.x = cvRound((r.x + nr.x + nr.width*0.5)*scale);
            center.y = cvRound((r.y + nr.y + nr.height*0.5)*scale);
            radius = cvRound((nr.width + nr.height)*0.25*scale);
            circle( img, center, radius, color, 3, 8, 0 );
        }

    }

}

int writevideo(int w,int h,int f,int save)
{	cap.open(0);
	if (!cap.isOpened())
	{   printf("open video error\n");
		return -1;
	}
	int ww = (int)cap.get(CV_CAP_PROP_FRAME_WIDTH); //����ͼ�����?
	int hh = (int)cap.get(CV_CAP_PROP_FRAME_HEIGHT);//����ͼ��߶�?
	int frameRate = cap.get(CV_CAP_PROP_FPS);	   //����ͼ��֡��
    printf("get input video is %dx%d @ %d\n",ww,hh,frameRate);
	if(ww!=w||hh!=h||frameRate!=f)
	{	int error=0;
		if(!cap.set(CV_CAP_PROP_FRAME_WIDTH,w)){
	   		printf("set input video width=%d failed\n",w);
			error++;
		}
		if(!cap.set(CV_CAP_PROP_FRAME_HEIGHT,h)){
			 printf("set input video hight=%d failed\n",h);
			 error++;
		}
		if(!cap.set(CV_CAP_PROP_FPS,f)){
			 printf("set input video fps=%d failed\n",f);
			 error++;
		}
		if(error) return -2;		
		printf("set video input %d*%d@%d\n",w,h,f);		
	}

	//���ط�����
    CascadeClassifier cascade, nestedCascade;
	cascade.load("haarcascade_frontalface_alt.xml");
	Mat srcImage, grayImage,dstImage;
	// ����7����ɫ�����ڱ������?
	Scalar colors[] =
	{
		// ��Ȼ���������?
		CV_RGB(255, 0, 0),
		CV_RGB(255, 97, 0),
		CV_RGB(255, 255, 0),
		CV_RGB(0, 255, 0),
		CV_RGB(0, 255, 255),
		CV_RGB(0, 0, 255),
		CV_RGB(160, 32, 240)
	};


	while (1)
	{
			if(!cap.read(srcImage)){	// ��2����ȡͼƬ
				usleep(1000);continue; 
			}

      		detectAndDraw( srcImage, cascade, nestedCascade, 1, 0 );
			#if 0

			printf("��⵽����������?%d\n", rect.size());

			// ��4�����?--��������Բ
			for (int i = 0; i < rect.size();i++)
			{
				Point  center;
				int radius;
				center.x = cvRound((rect[i].x + rect[i].width * 0.5));
				center.y = cvRound((rect[i].y + rect[i].height * 0.5));
				radius = cvRound((rect[i].width + rect[i].height) * 0.25);
				circle(dstImage, center, radius, colors[i % 7], 2);
			}
			#endif 
	}

	return 0;
}

int main(int argc ,char *argv[])
{
	if(argc!=4) 
	{	printf("usage :./kmbox 1366 768 30\n");
		return -1;
	}
	int w=atoi(argv[1]);
	int h=atoi(argv[2]);
	int f=atoi(argv[3]);
	writevideo(w,h,f,0);
	return 0;
}

#endif 