//Include Libraries
#include<opencv2/opencv.hpp>
#include<iostream>

// Namespace nullifies the use of cv::function(); 
using namespace std;
using namespace cv;

int main()
{
    // Read an image ��ȡbmp
    Mat img_grayscale = imread("test.bmp", 0); 
    imwrite("grayscale.bmp", img_grayscale);
    return 0;
}