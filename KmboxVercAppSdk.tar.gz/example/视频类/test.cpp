#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/time.h>
#include <fcntl.h>
#include <time.h>
#include <stdio.h>
#include <unistd.h>
#include <linux/input.h>
#include <pthread.h> 
#include <string.h>
#include <signal.h>
#include <semaphore.h>
#include <sys/select.h>  
#include <string.h>
#include <memory.h>
#include<opencv2/opencv.hpp>
#include<opencv2/videoio/videoio_c.h>
#include<iostream>
#include <opencv2/core/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/opencv.hpp>
#include <vector>
#include <cstdio>
 
using namespace std;
using namespace cv;
CascadeClassifier cascade, nestedCascade;

VideoCapture cap;
void help(){
	printf("-----------kmbox_openCV------------\n");
	printf("人脸识别\n");
	printf("-------------------------------\n");
}

 long GetUnixTime(){
    struct timeval stamp;
    gettimeofday(&stamp,NULL);
    return stamp.tv_sec*1000+stamp.tv_usec/1000;
}




void detectAndDraw( Mat& img, CascadeClassifier& cascade,
                    CascadeClassifier& nestedCascade,
                    double scale, bool tryflip )
{
    double t = 0;
    vector<Rect> faces;
    const static Scalar colors[] ={
        Scalar(255,0,0),
        Scalar(255,128,0),
        Scalar(255,255,0),
        Scalar(0,255,0),
        Scalar(0,128,255),
        Scalar(0,255,255),
        Scalar(0,0,255),
        Scalar(255,0,255)
    };
    Mat gray, smallImg;
    cvtColor( img, gray, COLOR_BGR2GRAY);//转换为灰度图
    double fx = 1 / scale;
    resize( gray, smallImg, Size(), fx, fx, INTER_LINEAR_EXACT);
    equalizeHist( smallImg, smallImg );//直方图均衡化增强对比度

    t = (double)getTickCount();
    cascade.detectMultiScale( smallImg, faces,
        1.1, 2, 0
        |CASCADE_SCALE_IMAGE,
        Size(30, 30) );
    t = (double)getTickCount() - t;
    printf( "detection time = %g ms  object=%d\n", t*1000/getTickFrequency()), faces.size();
    for ( size_t i = 0; i < faces.size(); i++ )
    {
        Rect r = faces[i];
        Mat smallImgROI;
        vector<Rect> nestedObjects;
        Point center;
        Scalar color = colors[i%8];
        int radius;

        double aspect_ratio = (double)r.width/r.height;
        if( 0.75 < aspect_ratio && aspect_ratio < 1.3 )
        {
            center.x = cvRound((r.x + r.width*0.5)*scale);
            center.y = cvRound((r.y + r.height*0.5)*scale);
            radius = cvRound((r.width + r.height)*0.25*scale);
            circle( img, center, radius, color, 3, 8, 0 );
        }
        else
            rectangle( img, Point(cvRound(r.x*scale), cvRound(r.y*scale)),
                       Point(cvRound((r.x + r.width-1)*scale), cvRound((r.y + r.height-1)*scale)),
                       color, 3, 8, 0);
        if( nestedCascade.empty() )
            continue;
    }

}

int writevideo(int w,int h,int f,int save)
{	cap.open(0);
	if (!cap.isOpened())
	{   printf("open video error\n");
		return -1;
	}
	int ww = (int)cap.get(CV_CAP_PROP_FRAME_WIDTH); //输入图像宽度
	int hh = (int)cap.get(CV_CAP_PROP_FRAME_HEIGHT);//输入图像高度
	int frameRate = cap.get(CV_CAP_PROP_FPS);	   //输入图像帧率
    printf("get input video is %dx%d @ %d\n",ww,hh,frameRate);
	if(ww!=w||hh!=h||frameRate!=f)
	{	int error=0;
		if(!cap.set(CV_CAP_PROP_FRAME_WIDTH,w)){
	   		printf("set input video width=%d failed\n",w);
			error++;
		}
		if(!cap.set(CV_CAP_PROP_FRAME_HEIGHT,h)){
			 printf("set input video hight=%d failed\n",h);
			 error++;
		}
		if(!cap.set(CV_CAP_PROP_FPS,f)){
			 printf("set input video fps=%d failed\n",f);
			 error++;
		}
		if(error) return -2;		
		printf("set video input %d*%d@%d\n",w,h,f);		
	}

	cascade.load("xml/haarcascade_frontalface_alt.xml");	//加载分类器
	Mat srcImage;
	while (1)
	{
			if(!cap.read(srcImage)){	//读取原始图片
				usleep(1000);continue; 
			}
      		detectAndDraw( srcImage, cascade, nestedCascade, 1, 0 );
	}

	return 0;
}

int main(int argc ,char *argv[])
{
	if(argc!=4) 
	{	printf("usage :./kmbox 1366 768 30\n");
		return -1;
	}
	int w=atoi(argv[1]);
	int h=atoi(argv[2]);
	int f=atoi(argv[3]);
	writevideo(w,h,f,0);
	return 0;
}
