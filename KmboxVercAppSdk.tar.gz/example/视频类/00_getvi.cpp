#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/time.h>
#include <fcntl.h>
#include <time.h>
#include <stdio.h>
#include <unistd.h>
#include <linux/input.h>
#include <pthread.h> 
#include <string.h>
#include <signal.h>
#include <semaphore.h>
#include <sys/select.h>  
#include <string.h>
#include <memory.h>
#include<opencv2/opencv.hpp>
#include<opencv2/videoio/videoio_c.h>
#include<iostream>
using namespace cv;
using namespace std;
 

VideoCapture cap;
void help()
{	printf("-----------kmbox_ai------------\n");
	printf("��ȡHDMI�ɼ���ͼ��Ĭ�����ΪYUV422ģʽ\n");
	printf("1920x1080@5Hz(�ڴ治��-֡��̫�Ͳ�ʵ��)\n");
	printf("1600x1200@5Hz(�ڴ治��)\n");
	printf("1360x768@8Hz(OK)\n");
	printf("1280X1240@8Hz(OK)\n");
	printf("1280X960@8Hz(OK)\n");
	printf("1280X720@10Hz(OK--�Ƽ�ʹ�����1920x1080\n");
	printf("1024X768@10Hz(OK)\n");
	printf("800X600@20/10/5Hz(OK)\n");
	printf("720X576@25/20/10/5Hz(OK)\n");
	printf("720X480@30/20/10/5Hz(OK)\n");
	printf("640X480@30/20/10/5Hz(OK)\n");
    printf("ctr+c�˳�\n");
	printf("-------------------------------\n");
}

 long GetUnixTime(){
    struct timeval stamp;
    gettimeofday(&stamp,NULL);
    return stamp.tv_sec*1000+stamp.tv_usec/1000;
}



int writevideo(int w,int h,int f,char*save)
{	cap.open(0);
	if (!cap.isOpened())
	{   printf("open video error\n");
		return -1;
	}
	int ww = (int)cap.get(CV_CAP_PROP_FRAME_WIDTH); //��ȡ�������
	int hh = (int)cap.get(CV_CAP_PROP_FRAME_HEIGHT);//��ȡ����߶�
	int frameRate = cap.get(CV_CAP_PROP_FPS);	    //��ȡ֡��
    printf("get input video is %dx%d @ %d\n",ww,hh,frameRate);
	if(ww!=w||hh!=h||frameRate!=f)//������벻�����������ľ���������
	{	int error=0;
		if(!cap.set(CV_CAP_PROP_FRAME_WIDTH,w)){
	   		printf("set input video width=%d failed\n",w);
			error++;
		}
		if(!cap.set(CV_CAP_PROP_FRAME_HEIGHT,h)){
			 printf("set input video hight=%d failed\n",h);
			 error++;
		}
		if(!cap.set(CV_CAP_PROP_FPS,f)){
			 printf("set input video fps=%d failed\n",f);
			 error++;
		}
		if(error) return -2;		
		printf("set video input %d*%d@%d\n",w,h,f);		
	}

	Mat frame;//����ͼ��洢mat
	while (1)
	{   long starttime=GetUnixTime();
        if(!cap.read(frame)){
           continue; //����Ƶ�ź�
        }
        long endtime=GetUnixTime();
        printf("startime =%ld nowtime=%ld diff=%ld \n",starttime,endtime,endtime-starttime);//ͳ�ƺ�ʱ
	}
	return 0;
}

int main(int argc ,char *argv[])
{
	if(argc!=4) 
	{	printf("usage :./getvi 1280 720 10\n");
	    help();
		return -1;
	}
	help();
	int w=atoi(argv[1]);
	int h=atoi(argv[2]);
	int f=atoi(argv[3]);
	writevideo(w,h,f,0);
	return 0;
}

