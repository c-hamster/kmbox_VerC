#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/time.h>
#include <fcntl.h>
#include <time.h>
#include <stdio.h>
#include <unistd.h>
#include <linux/input.h>
#include <pthread.h> 
#include <string.h>
#include <signal.h>
#include <semaphore.h>
#include <sys/select.h>  
#include <string.h>
#include <memory.h>
#include<opencv2/opencv.hpp>
#include<opencv2/videoio/videoio_c.h>
#include<iostream>
#include <opencv2/core/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/opencv.hpp>
#include <vector>
#include <cstdio>
 
using namespace std;
using namespace cv;

void help(){
	printf("-----------kmbox_openCV------------\n");
	printf("抠图（截取部分图像）\n");
	printf("-------------------------------\n");
}

 long GetUnixTime(){
    struct timeval stamp;
    gettimeofday(&stamp,NULL);
    return stamp.tv_sec*1000+stamp.tv_usec/1000;
}


int main(int argc ,char *argv[])
{	if(argc!=6) 
	{	printf("usage :./roi path x y w h\n");
		return -1;
	}
	int x=atoi(argv[2]);
	int y=atoi(argv[3]);
	int w=atoi(argv[4]);
    int h=atoi(argv[5]);
    Mat src=imread(argv[1]);
    


	return 0;
}
