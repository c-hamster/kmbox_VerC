/**
�����ͼ
**/
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/time.h>
#include <fcntl.h>
#include <time.h>
#include <stdio.h>
#include <unistd.h>
#include <linux/input.h>
#include <pthread.h> 
#include <string.h>
#include <signal.h>
#include <semaphore.h>
#include <sys/select.h>  
#include <string.h>
#include <memory.h>
#include<opencv2/opencv.hpp>
#include<opencv2/videoio/videoio_c.h>
#include<iostream>
using namespace cv;
using namespace std;

#define DEMO "01_printscreen"
VideoCapture cap;


void powerup()
{  
}


void help()
{
	printf("-----------kmbox_openCV------------\n");
	printf("������ͼ�񱣴�Ϊbmp\n");
	printf("1920x1080@5Hz(�ڴ治���޷�����)\n");
	printf("1600x1200@5Hz(�ڴ治���޷�����)\n");
	printf("1360x768@8Hz(OK)\n");
	printf("1280X1240@8Hz(OK)\n");
	printf("1280X960@8Hz(OK)\n");
	printf("1280X720@10Hz(OK--�Ƽ�ʹ�� ����1920x1080)\n");
	printf("1024X768@10Hz(OK)\n");
	printf("800X600@20/10/5Hz(OK)\n");
	printf("720X576@25/20/10/5Hz(OK)\n");
	printf("720X480@30/20/10/5Hz(OK)\n");
	printf("640X480@30/20/10/5Hz(OK)\n");
    printf("�س���ͼ��ctr+c�˳�\n");
	printf("-------------------------------\n");
}

 long GetUnixTime(){
    struct timeval stamp;
    gettimeofday(&stamp,NULL);
    return stamp.tv_sec*1000+stamp.tv_usec/1000;
}



int writevideo(int w,int h,int f,int save)
{	cap.open(0);
	if (!cap.isOpened())
	{   printf("open video error\n");
		return -1;
	}
	int ww = (int)cap.get(CV_CAP_PROP_FRAME_WIDTH); //����ͼ�����
	int hh = (int)cap.get(CV_CAP_PROP_FRAME_HEIGHT);//����ͼ��߶�
	int frameRate = cap.get(CV_CAP_PROP_FPS);	    //����ͼ��֡��
    printf("get input video is %dx%d @ %d\n",ww,hh,frameRate);
	if(ww!=w||hh!=h||frameRate!=f)
	{	int error=0;
		if(!cap.set(CV_CAP_PROP_FRAME_WIDTH,w)){
	   		printf("set input video width=%d failed\n",w);
			error++;
		}
		if(!cap.set(CV_CAP_PROP_FRAME_HEIGHT,h)){
			 printf("set input video hight=%d failed\n",h);
			 error++;
		}
		if(!cap.set(CV_CAP_PROP_FPS,f)){
			 printf("set input video fps=%d failed\n",f);
			 error++;
		}
		if(error) return -2;		
		printf("set video input %d*%d@%d\n",w,h,f);		
	}

	Mat frame;
    char name[128];
	while (1)
	{
        if(getchar()=='\n')
        {  
			if(!cap.read(frame)){
				usleep(1000);continue; //����Ƶ�ź�
			}
			long t1=GetUnixTime();
            sprintf(name,"%dx%d@%d_%03ld.bmp",w,h,f,GetUnixTime());
            printf("save %s  ...",name);
	        imwrite(name, frame);
            printf("ok [used %ld ms]\n",GetUnixTime()-t1);
        }
	}
	return 0;
}


int main(int argc ,char *argv[])
{
	if(argc!=4) 
	{	printf("usage :./%s 1280 720 10\n",DEMO);
		return -1;
	}
	powerup();
    help();
	int w=atoi(argv[1]);
	int h=atoi(argv[2]);
	int f=atoi(argv[3]);
	writevideo(w,h,f,0);
	return 0;
}

