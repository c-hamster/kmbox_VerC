/*
模板匹配（找图）
*/
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/time.h>
#include <fcntl.h>
#include <time.h>
#include <stdio.h>
#include <unistd.h>
#include <linux/input.h>
#include <pthread.h> 
#include <string.h>
#include <signal.h>
#include <semaphore.h>
#include <sys/select.h>  
#include <string.h>
#include <memory.h>
#include<opencv2/opencv.hpp>
#include<opencv2/videoio/videoio_c.h>
#include<iostream>
using namespace cv;
using namespace std;
long GetUnixTime(){
    struct timeval stamp;
    gettimeofday(&stamp,NULL);
    return stamp.tv_sec*1000+stamp.tv_usec/1000;
}


//模板匹配函数
void templateMatching(const Mat& srcImage,const Mat& templateImage)
{
    Mat result;
    long t1=GetUnixTime();
    int result_cols = srcImage.cols - templateImage.cols + 1;
    int result_rows = srcImage.rows - templateImage.rows + 1;
    if(result_cols < 0 || result_rows < 0)
    {
        return;
    }
    result.create(result_cols, result_rows, CV_32FC1);
//  enum { TM_SQDIFF=0, TM_SQDIFF_NORMED=1, TM_CCORR=2, TM_CCORR_NORMED=3, TM_CCOEFF=4, TM_CCOEFF_NORMED=5 };
    matchTemplate(srcImage,templateImage,result,TM_SQDIFF);   //最好匹配为1,值越小匹配越差
    double minVal = -1;
    double maxVal;
    Point minLoc,maxLoc,matchLoc;
    minMaxLoc(result, &minVal, &maxVal, &minLoc, &maxLoc, Mat());

 //取大值(视匹配方法而定) 
    matchLoc = maxLoc;
    printf("minVal=%f maxVal=%f  minLoc(%d,%d) maxLoc(%d,%d) using %d ms\n",minVal,maxVal,minLoc.x,minLoc.y,maxLoc.x,maxLoc.y,GetUnixTime()-t1);
}

VideoCapture cap;
void help()
{
	printf("-----------kmbox_openCV------------\n");
	printf("模板匹配算法\n");
    printf("ctr+c退出\n");
	printf("-------------------------------\n");
}




int writevideo(int w,int h,int f,char*save)
{	cap.open(0);
	if (!cap.isOpened())
	{   printf("open video error\n");
		return -1;
	}
	int ww = (int)cap.get(CV_CAP_PROP_FRAME_WIDTH); //输入图像宽度
	int hh = (int)cap.get(CV_CAP_PROP_FRAME_HEIGHT);//输入图像高度
	int frameRate = cap.get(CV_CAP_PROP_FPS);	    //输入图像帧率
    printf("get input video is %dx%d @ %d\n",ww,hh,frameRate);
	if(ww!=w||hh!=h||frameRate!=f)
	{	int error=0;
		if(!cap.set(CV_CAP_PROP_FRAME_WIDTH,w)){
	   		printf("set input video width=%d failed\n",w);
			error++;
		}
		if(!cap.set(CV_CAP_PROP_FRAME_HEIGHT,h)){
			 printf("set input video hight=%d failed\n",h);
			 error++;
		}
		if(!cap.set(CV_CAP_PROP_FPS,f)){
			 printf("set input video fps=%d failed\n",f);
			 error++;
		}
		if(error) return -2;		
		printf("set video input %d*%d@%d\n",w,h,f);		
	}

	Mat frame,templ;
    templ=imread(save);
	while (1)
	{
        if(!cap.read(frame)){
            usleep(1000);continue; //无视频信号
        }
        templateMatching(frame,templ);
    
	}
	return 0;
}

int main(int argc ,char *argv[])
{
	if(argc!=5) 
	{	printf("usage :./templateMatching 1280 720 10 path_of_picture\n");
		return -1;
	}
    help();
	int w=atoi(argv[1]);
	int h=atoi(argv[2]);
	int f=atoi(argv[3]);
	writevideo(w,h,f,argv[4]);
	return 0;
}

